#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"
if ! command -v "$GODOT_BIN" >/dev/null 2>&1; then
  echo "لم يتم العثور على Godot. ثبّت Godot 4 وأعد المحاولة." >&2
  exit 1
fi
mkdir -p "$PROJECT_DIR/build"
"$GODOT_BIN" --headless --path "$PROJECT_DIR" --editor --quit
"$GODOT_BIN" --headless --path "$PROJECT_DIR" --export-debug "Android" "$PROJECT_DIR/build/FootballStars3D-debug.apk"
echo "تم إنشاء APK في: $PROJECT_DIR/build/FootballStars3D-debug.apk"
