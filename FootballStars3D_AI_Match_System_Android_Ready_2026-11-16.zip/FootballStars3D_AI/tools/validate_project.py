#!/usr/bin/env python3
"""Lightweight static checks for the Football Stars 3D Godot source tree.
This is not a replacement for Godot's GDScript parser or an in-engine test.
"""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "main.gd"
SCENE = ROOT / "scenes" / "Main.tscn"
PROJECT = ROOT / "project.godot"

errors: list[str] = []
checks: list[str] = []

for path in (SCRIPT, SCENE, PROJECT):
    if path.is_file():
        checks.append(f"exists: {path.relative_to(ROOT)}")
    else:
        errors.append(f"missing file: {path.relative_to(ROOT)}")

if errors:
    print("FAIL")
    print("\n".join(errors))
    sys.exit(1)

source = SCRIPT.read_text(encoding="utf-8")
scene = SCENE.read_text(encoding="utf-8")
project = PROJECT.read_text(encoding="utf-8")

if 'renderer/rendering_method="gl_compatibility"' in project and 'renderer/rendering_method.mobile="gl_compatibility"' in project:
    checks.append("GL Compatibility renderer configured for desktop and mobile")
else:
    errors.append("GL Compatibility renderer configuration missing")

if 'path="res://scripts/main.gd"' in scene:
    checks.append("main scene references scripts/main.gd")
else:
    errors.append("main scene script reference missing")

func_defs = re.findall(r"^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", source, re.M)
if len(func_defs) == len(set(func_defs)):
    checks.append(f"unique function declarations: {len(func_defs)}")
else:
    errors.append("duplicate function declarations detected")

required_functions = [
    "_update_players", "_second_nearest_player_index", "_nearest_opponent_index",
    "_best_pass_target_for_team", "_distance_to_segment", "_shot_lane_clear",
    "_try_goalkeeper_save", "_animate_player",
]
for name in required_functions:
    if re.search(rf"^func\s+{re.escape(name)}\s*\(", source, re.M):
        checks.append(f"AI feature function present: {name}")
    else:
        errors.append(f"required function missing: {name}")

# All calls to local underscore-prefixed methods must have a matching declaration.
called = set(re.findall(r"(?<![A-Za-z0-9])(_[A-Za-z][A-Za-z0-9_]*)\s*\(", source))
defined = set(func_defs)
undefined = sorted(called - defined)
if undefined:
    errors.append("undefined local method call(s): " + ", ".join(undefined))
else:
    checks.append("all underscore-prefixed method calls have declarations")

if "var blue_cover := _second_nearest_player_index" in source and "var white_cover := _second_nearest_player_index" in source:
    checks.append("both teams assign a second pressing/cover player")
else:
    errors.append("coordinated second-player pressure missing")

if "_distance_to_segment(defender.position, from, lead_position)" in source:
    checks.append("pass selection evaluates defender interception lanes")
else:
    errors.append("pass-lane interception scoring missing")

if "receiver.position + receiver_velocity * 0.22" in source:
    checks.append("passes lead moving receivers")
else:
    errors.append("receiver lead pass logic missing")

# Dribbling, feint and tackle controls must be wired from keyboard and touch HUD.
for name in ["_perform_dribble_skill", "_perform_feint", "_perform_tackle", "_controlled_move_direction", "_has_ball_control"]:
    if re.search(rf"^func\s+{re.escape(name)}\s*\(", source, re.M):
        checks.append(f"skill system function present: {name}")
    else:
        errors.append(f"skill system function missing: {name}")
for token, label in [
    ('_make_touch_button(layer, "مراوغة"', "mobile dribble button is present"),
    ('_make_touch_button(layer, "خدعة"', "mobile feint button is present"),
    ('_make_touch_button(layer, "افتكاك"', "mobile tackle button is present"),
    ('KEY_E, KEY_Q, KEY_C', "keyboard skill controls are wired"),
    ('skill_cooldown = 1.65', "dribble skill cooldown prevents repeated boosting"),
    ('feint_cooldown = 1.15', "feint cooldown is enforced"),
    ('tackle_cooldown = 1.0', "tackle cooldown is enforced"),
    ('"dribble": ["dribble", "dribbling", "skill_move"]', "GLB dribble animation aliases are supported"),
    ('"feint": ["feint", "body_feint", "side_step"]', "GLB feint animation aliases are supported"),
    ('"tackle": ["tackle", "sliding_tackle", "steal"]', "GLB tackle animation aliases are supported"),
]:
    if token in source:
        checks.append(label)
    else:
        errors.append(f"missing skill feature: {label}")

glb_paths = ["assets/player_home.glb", "assets/player_away.glb", "assets/goalkeeper.glb"]
if all((ROOT / path).is_file() for path in glb_paths) and "res://assets/player_home.glb" in source and "res://assets/player_away.glb" in source and "res://assets/goalkeeper.glb" in source:
    checks.append("three team-specific GLB character assets are present and referenced")
else:
    errors.append("one or more team-specific GLB character assets are missing or not referenced")
if "_find_animation_player" in source and "_play_model_animation" in source and 'if p.get("model_animator") != null:' in source:
    checks.append("optional AnimationPlayer clips supported; procedural limb animation remains active without clips")
else:
    errors.append("AnimationPlayer fallback handling missing")

if 'action_anim = "save"' in source and "goalkeeper_save_cooldown" in source:
    checks.append("goalkeeper save response and cooldown present")
else:
    errors.append("goalkeeper save response missing")

if "(team == 0 and ball_vel.z > 0.0) or (team == 1 and ball_vel.z < 0.0)" in source:
    checks.append("goalkeeper save direction matches the teams' defended goal ends")
else:
    errors.append("goalkeeper save direction is inconsistent with team attack directions")

# Small deterministic logic checks for the direction and segment-distance rules used above.
def distance_to_segment(point, start, finish):
    segment = tuple(finish[k] - start[k] for k in range(3))
    length_sq = sum(v * v for v in segment)
    if length_sq < 0.001:
        return sum((point[k] - start[k]) ** 2 for k in range(3)) ** 0.5
    amount = max(0.0, min(1.0, sum((point[k] - start[k]) * segment[k] for k in range(3)) / length_sq))
    closest = tuple(start[k] + segment[k] * amount for k in range(3))
    return sum((point[k] - closest[k]) ** 2 for k in range(3)) ** 0.5

assert ( -10.0 * -1.0) > 0.0  # blue progresses toward negative Z
assert ( 10.0 *  1.0) > 0.0  # white progresses toward positive Z
assert abs(distance_to_segment((5, 0, 2), (0, 0, 0), (10, 0, 0)) - 2.0) < 1e-6
assert abs(distance_to_segment((5, 0, 0), (0, 0, 0), (10, 0, 0))) < 1e-6
checks.append("directional pass-progress and pass-lane geometry smoke tests")

# New animation polish: procedural body motion and directional goalkeeper dive.
for token, label in [
    ('is_dribbling', 'dribble posture responds to nearby ball'),
    ('model.rotation.x = -0.10', 'sprint body lean is animated'),
    ('model.rotation.x = -0.24', 'shot follow-through body lean is animated'),
    ('keeper_data.save_direction = dive_direction', 'goalkeeper dive direction is stored'),
    ('model.position.x = dive_direction * 0.82', 'goalkeeper body translates into lateral dive'),
    ('arms[0].rotation.z = -save_direction', 'goalkeeper arms extend during dive'),
]:
    if token in source:
        checks.append(label)
    else:
        errors.append(f"missing animation feature: {label}")

# Check balanced delimiters while ignoring comments and quoted strings.
stack: list[tuple[str, int]] = []
pairs = {")": "(", "]": "[", "}": "{"}
opens = set(pairs.values())
in_string: str | None = None
escaped = False
for line_no, line in enumerate(source.splitlines(), 1):
    i = 0
    while i < len(line):
        ch = line[i]
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == in_string:
                in_string = None
            i += 1
            continue
        if ch == "#":
            break
        if ch in ("'", '"'):
            in_string = ch
        elif ch in opens:
            stack.append((ch, line_no))
        elif ch in pairs:
            if not stack or stack[-1][0] != pairs[ch]:
                errors.append(f"unmatched {ch!r} on line {line_no}")
                break
            stack.pop()
        i += 1
if in_string:
    errors.append("unterminated quoted string")
if stack:
    errors.append("unclosed delimiter(s): " + ", ".join(f"{ch} at line {ln}" for ch, ln in stack))
if not in_string and not stack:
    checks.append("quoted strings and bracket delimiters are structurally balanced")

if "\t" not in source:
    checks.append("GDScript indentation uses spaces (no tab characters)")
else:
    errors.append("tab character found in GDScript; use spaces for indentation")

# Signature skills, shot variants and goal celebrations added in this release.
for name in ["_start_360_dribble", "_use_player_signature_skill", "_shoot_curved", "_shoot_long_range", "_celebrate_goal"]:
    if re.search(rf"^func\s+{re.escape(name)}\s*\(", source, re.M):
        checks.append(f"new gameplay function present: {name}")
    else:
        errors.append(f"new gameplay function missing: {name}")
for token, label in [
    ('"skill_profile": ("ronaldo" if number == 7 else ("messi" if number == 10 else "standard"))', "shirt numbers 7 and 10 receive Ronaldo/Messi signature profiles"),
    ('elif keycode == KEY_R:', "360-degree roulette is keyboard/touch wired"),
    ('elif keycode == KEY_T:', "signature player skill is keyboard/touch wired"),
    ('elif keycode == KEY_L:', "curved shot is keyboard/touch wired"),
    ('elif keycode == KEY_U:', "long-range shot is keyboard/touch wired"),
    ('elif keycode == KEY_H:', "goal celebration replay is keyboard/touch wired"),
    ('ball_curve_strength = -5.5 if ball_pos.x > 0.0 else 5.5', "curved shot applies lateral ball acceleration"),
    ('ball_vel = goal_dir * 27.0 + Vector3(0, 6.0, 0)', "long-range shot has a distinct power/loft profile"),
    ('celebration_team = 0', "blue team goal assigns correct celebration team"),
    ('celebration_team = 1', "white team goal assigns correct celebration team"),
    ('"roulette": ["roulette", "spin", "360_dribble"]', "GLB animation aliases include 360 spin"),
    ('"celebrate": ["celebrate", "celebration", "goal_celebration"]', "GLB animation aliases include celebrations"),
]:
    if token in source:
        checks.append(label)
    else:
        errors.append(f"missing new gameplay feature: {label}")
if source.count('var skill_cooldown := 0.0') == 1:
    checks.append("skill cooldown has one declaration")
else:
    errors.append("duplicate skill cooldown declaration")
if source.count('func _has_ball_control(') == 1:
    checks.append("ball-control helper has one declaration")
else:
    errors.append("duplicate ball-control helper declaration")


# Match setup menu, selectable squads/formations and Android export preparation.
for name in ["_build_match_menu", "_add_menu_option", "_start_match_from_menu", "_apply_formation"]:
    if re.search(rf"^func\s+{re.escape(name)}\s*\(", source, re.M):
        checks.append(f"match setup function present: {name}")
    else:
        errors.append(f"match setup function missing: {name}")
for token, label in [
    ('"4-4-2", "4-3-3", "3-5-2"', "three selectable tactical formations are offered"),
    ('"10 — صانع الألعاب (مهارة ميسي)"', "player selection includes Messi-style number 10"),
    ('"7 — الجناح (مهارة رونالدو)"', "player selection includes Ronaldo-style number 7"),
    ('match_started = true', "kickoff starts the match after menu confirmation"),
    ('if not match_started or match_paused:', "match clock and simulation wait for kickoff and pause state"),
    ('if keycode == KEY_P:', "pause/resume control is wired"),
    ('_make_touch_button(layer, "إيقاف"', "mobile pause button is present"),
]:
    if token in source:
        checks.append(label)
    else:
        errors.append(f"missing match setup feature: {label}")

preset = ROOT / "export_presets.cfg"
build_script = ROOT / "BUILD_ANDROID.sh"
if preset.is_file() and 'platform="Android"' in preset.read_text(encoding="utf-8") and 'package/unique_name="com.footballstars3d.game"' in preset.read_text(encoding="utf-8"):
    checks.append("Android export preset exists with package identifier")
else:
    errors.append("Android export preset missing or incomplete")
if build_script.is_file() and "--export-debug \"Android\"" in build_script.read_text(encoding="utf-8"):
    checks.append("Android build script checks dependencies and exports debug APK")
else:
    errors.append("Android build script missing export command")

# Verify the intended formation shapes and roster sizes independently.
formation_counts = {"4-4-2": (4, 4, 2), "4-3-3": (4, 3, 3), "3-5-2": (3, 5, 2)}
for formation, (defenders_count, midfielders_count, forwards_count) in formation_counts.items():
    assert 1 + defenders_count + midfielders_count + forwards_count == 11
    checks.append(f"formation roster count is 11: {formation}")

print(f"Football Stars 3D static validation: {len(checks)} checks")
for item in checks:
    print(f"PASS  {item}")
for item in errors:
    print(f"FAIL  {item}")
if errors:
    sys.exit(1)
print("\nStatic validation passed. Godot parsing/runtime and Android export are NOT covered.")
