#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
GODOT_BIN="${GODOT_BIN:-godot}"

if ! command -v "$GODOT_BIN" >/dev/null 2>&1; then
  echo "لم يتم العثور على Godot 4. ثبّت المحرك ثم أعد المحاولة." >&2
  exit 2
fi
if [[ -z "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]]; then
  echo "ANDROID_HOME أو ANDROID_SDK_ROOT غير مضبوط. ثبّت Android SDK واضبط المسار." >&2
  exit 3
fi
if ! command -v java >/dev/null 2>&1; then
  echo "لم يتم العثور على Java/JDK. ثبّت إصدار JDK المتوافق مع إصدار Godot." >&2
  exit 4
fi
mkdir -p "$PROJECT_DIR/build"
python3 "$PROJECT_DIR/tools/validate_project.py"
"$GODOT_BIN" --headless --path "$PROJECT_DIR" --editor --quit
"$GODOT_BIN" --headless --path "$PROJECT_DIR" --export-debug "Android" "$PROJECT_DIR/build/FootballStars3D-debug.apk"
test -s "$PROJECT_DIR/build/FootballStars3D-debug.apk"
echo "تم إنشاء APK: $PROJECT_DIR/build/FootballStars3D-debug.apk"
